# VEXORA — Media Downloader

Downloader multi-platform dengan tema neumorphism monokrom (V13, mode Dark + Light). Frontend statis + satu Vercel serverless function yang menjalankan scraper dari [coflyn/scrapr](https://github.com/coflyn/scrapr) (MIT) secara berantai (fallback).

## Deploy ke Vercel

1. Upload folder ini ke GitHub (atau `vercel` CLI dari folder ini).
2. Import di Vercel. Framework: **Other**. Tidak perlu build command.
3. Selesai. `vercel.json` sudah mengatur `maxDuration` 60 detik untuk `/api/download`.

## Struktur

```
index.html            halaman utama
assets/style.css      tema neumorphism dark/light
assets/app.js         UI (10 layar), deteksi platform, riwayat, profil
assets/i18n.js        10 bahasa (kamus + mesin terjemah)
assets/images/        tempat gambar/poster yang bisa kamu isi sendiri
assets/video/hero.mp4 video utama halaman beranda (isi sendiri)
api/download.js       endpoint: deteksi platform -> fallback chain -> JSON seragam
api/_lib/platforms.js daftar platform & urutan scraper (edit di sini)
scrapr/               salinan lib scrapr (MIT) tanpa scraper berbasis browser
```

## Mengisi aset visual

- Video banner Home: `assets/video/hero.mp4` (terpasang, 1920x1080). Autoplay, muted, loop, playsinline.
- Daftar gambar yang dibutuhkan, lengkap dengan ukurannya, ada di `assets/images/README.txt`. Selama belum diisi, aplikasi tetap jalan dengan latar gelap.
- Semua gambar di `assets/images/` sudah terisi. `assets/video/hero.mp4` juga sudah terpasang (1080p, tanpa audio, ±4,5 MB, faststart).
- Video tanpa audio dan ukuran terkompresi disarankan agar lebih nyaman di ponsel.

## API

```
POST /api/download   { "url": "https://...", "format": "mp4" | "mp3" }   // format hanya untuk YouTube
```

Sukses: `{ ok, platform, via, title, thumbnail, type, author, downloads:[{url,type,quality,label,size,ext}] }`
Gagal: `{ ok:false, error, tried:[{name,error}] }`

## Platform

TikTok, Instagram, YouTube, Facebook, X/Twitter, Threads, Pinterest, Spotify, SoundCloud, Apple Music, Bandcamp, Bilibili, Douyin, RedNote, Reddit, Terabox, Pixiv.

## Catatan penting

- Scrapr membungkus situs downloader pihak ketiga, jadi sewaktu-waktu satu scraper bisa rusak. Itu sebabnya tiap platform punya beberapa scraper berurutan. Kalau ada yang mati, kirim issue ke repo scrapr atau perbarui folder `scrapr/` dengan versi terbaru lalu deploy ulang.
- Tiga scraper berbasis browser (`facebook/fdown`, `instagram/snapinsta`, `tiktok/savetik`) dan `tiktok/tikdownloader` (butuh `child_process`) **sengaja dibuang**: tidak jalan di Vercel serverless.
- Beberapa scraper lambat (SoundCloud, Bilibili bisa 10–60 detik). Batas total fungsi diatur 54 detik.
- Rate limit 12 request/menit/IP bersifat best-effort (memori per instance). Untuk trafik publik besar, pakai Vercel KV/Upstash.
- Tombol Unduh membuka link CDN langsung. Browser kadang memutar file alih-alih menyimpannya; tekan lama lalu Simpan.
- Gunakan hanya untuk konten milikmu atau yang boleh diunduh; patuhi ketentuan tiap platform.

## Catatan V12 (Premium Chrome)

- **Logo**: `assets/images/vexora-logo.svg` digambar ulang sebagai vektor persis dari logo referensi (chrome dua tingkat). Dipakai di splash, header, modal Download Engine; `vexora-icon.svg` + PNG (192/512/apple-touch) untuk favicon & ikon aplikasi.
- **Splash**: logo tampil dengan animasi per potongan + kilau. Jika `assets/video/splash-gojo.mp4` tidak ada, splash otomatis menutup ±3,4 detik (batas maksimum 9 detik).
- **Download Engine**: modal proses (cincin presisi, langkah bernomor, sinyal live) dan sheet unduhan versi ringkas (±320px).
- **Perbaikan bug CSS**: 148 deklarasi `rgba(...)` kehilangan tanda `(` (sisa konversi monokrom) sehingga bayangan/glow/background dibuang browser. Sudah diperbaiki.
- Logika `api/download.js`, scraper, dan alur unduhan tidak diubah.

## API fallback tambahan (opsional)

Fallback API eksternal bersifat opt-in dan tidak mengubah scraper yang sudah ada. Untuk mengaktifkannya, deploy/self-host API yang Anda kendalikan lalu atur environment variable berikut di deployment VEXORA:

- `VEXORA_UNIVERSAL_DOWNLOADER_URL` (nama lama `AVX_UNIVERSAL_DOWNLOADER_URL` tetap didukung): base URL instance `universalDownloader` (tanpa slash di akhir). VEXORA mencoba route `/api/{platform}/download` setelah seluruh scraper bawaan gagal.
- `VEXORA_YTDLP_API_URL` (nama lama `AVX_YTDLP_API_URL` tetap didukung): URL endpoint `/download` instance FastAPI berbasis `yt-dlp`. Endpoint contoh tersebut mengembalikan stream file, bukan URL unduhan; karena itu fallback ini hanya melakukan pemeriksaan kompatibilitas dan tidak dianggap sukses jika respons bukan URL yang dapat dipakai VEXORA.

API eksternal tidak disertakan sebagai layanan publik aktif. Gunakan hanya instance yang Anda kelola dan konten yang boleh diunduh.

## Catatan V13 (Neumorphism, 10 layar)

- **Layar**: Splash (lalu fade-in), Home, Pilih Platform, Input URL, Proses Download, Hasil Download, Riwayat, Profil/Pengaturan, About, plus layar "Siap Diunduh" (pilih kualitas) dan tab Saved.
- **Proses link dan proses unduh** tampil sebagai layar penuh dengan isi di tengah (tidak lagi bottom sheet).
- **Riwayat** kosong sampai ada file yang berhasil diunduh; disimpan lokal (localStorage), bisa difilter Video/Audio/Gambar.
- **Profil**: nama bisa diganti dan logo/foto bisa diganti (di-crop persegi 256px, disimpan lokal). Tema Dark/Light bisa diganti.
- **Reset Data** (menggantikan "Keluar") menghapus semua data lokal VEXORA di browser.
- Logika `api/download.js`, scraper, dan alur unduhan tidak diubah.

## Catatan V3 (Rebrand VEXORA)

- **Nama**: AVX → **VEXORA** (judul, meta/OG, splash, header, About, Profil, teks FAQ, nama file unduhan, `package.json`, `manifest.webmanifest`).
- **Logo baru**: tanda "V" dari gambar referensi di-trace jadi vektor (`assets/images/vexora-logo.svg`), latar dihapus. File 4K transparan ada di `assets/brand/`.
- **Ikon**: `icon-192/512/1024`, `icon-maskable-512`, `apple-touch-icon`, `vexora-icon.svg`.
- **Splash**: 3 detik, tanpa layar loading, lalu fade-in ke Home.
- Kunci penyimpanan lokal berganti dari `avx.*` ke `vexora.*`, jadi riwayat/profil lama di browser tidak terbawa.
- **Font nama**: tulisan 𝐕𝐄𝐗𝐎𝐑𝐀 memakai karakter Unicode Mathematical Bold. Glyph-nya (6 huruf) di-embed di `assets/fonts/vexora-bold.woff` (Latin Modern Math, subset ±2 KB) supaya tampil sama di semua HP, tidak bergantung font sistem.

## Catatan V3.0.0 (rilis APK)

- **Versi**: V3.0.0 (Android `versionName 3.0.0`, `versionCode 300`). Nama aplikasi: **VEXORA**.
- **Footer unduh**: `download-footer.webp` kini 1080x620, gambar Gojo bersih dari teks, atasnya sudah di-blend ke hitam. Avatar bawaan profil = Gojo.
- **API**: ditambah header CORS (website, PWA, dan APK bisa memanggil `/api/download`), endpoint `GET /api/health` (status + daftar platform/scraper), dan mode diagnosa `GET /api/health?url=...&key=...` yang menguji SEMUA scraper satu platform (aktif jika env `VEXORA_ADMIN_KEY` diisi).
- **Frontend**: `assets/config.js` (`apiBase`) agar APK memanggil API di Vercel; unduhan di APK memakai DownloadManager Android (progres + notifikasi, file masuk `Download/VEXORA`).
- **PWA**: `sw.js` (cache kerangka app, `/api/*` tidak pernah di-cache) + manifest diperlengkapi.
- **Vercel**: header cache aset, `.vercelignore` (folder APK/skrip tidak ikut deploy).
- **Tes endpoint**: `node scripts/test-endpoints.js https://domainmu.vercel.app` (isi link contoh di `scripts/test-urls.json`).

### Membuat APK

Lihat `android-apk/README.md` (GitHub Actions otomatis, atau manual lewat Android Studio).

### Environment variable (Vercel)

| Nama | Fungsi |
|---|---|
| `VEXORA_ADMIN_KEY` | (opsional) mengaktifkan mode diagnosa `/api/health?url=...` |
| `VEXORA_UNIVERSAL_DOWNLOADER_URL` | (opsional) fallback API universalDownloader milik sendiri |
| `VEXORA_YTDLP_API_URL` | (opsional) fallback yt-dlp; hanya pengecekan, tidak menghasilkan link |

## Multi-bahasa (10 bahasa)

Aplikasi selalu **mulai dalam English**. Pengguna bisa mengganti bahasa di **Profil → Language/Bahasa**; pilihan disimpan di browser (`vexora.settings.v1` → `lang`) dan dipakai lagi saat dibuka berikutnya.

English · Bahasa Indonesia · Español · Português · Français · Deutsch · Русский · العربية (RTL otomatis) · हिन्दी · 日本語

- Semua teks ada di `assets/i18n.js` (satu blok per bahasa, kunci sama di semua bahasa). Kunci yang belum ada otomatis jatuh ke English.
- Teks statis di `index.html` memakai atribut `data-i18n="kunci"` / `data-i18n-attr="aria-label:kunci"`; teks dinamis di `app.js` memakai `t("kunci", {var})`.
- Tambah bahasa baru: tambahkan entri di `LANGS` dan kamusnya di `D` pada `assets/i18n.js`.
- Pesan error dari API sekarang membawa `code` (`rate`, `badurl`, `unsupported`, `allfailed`, `method`) sehingga diterjemahkan di sisi klien; `error` tetap berisi teks English sebagai cadangan.


## Public repository security note

API credentials are intentionally replaced with placeholders in this public-ready copy. Do not commit real API tokens or keys to frontend JavaScript: anything shipped to the browser is public. Configure secrets as server-side environment variables in your deployment and rotate any credentials that were previously exposed.
