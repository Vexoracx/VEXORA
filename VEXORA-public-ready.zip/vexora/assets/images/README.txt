VEXORA IMAGE ASSETS (V3.0.0)

Semua aset sudah terpasang (grayscale, tanpa teks/logo/UI, WebP q90):

- splash-bg.webp        1080 x 2340   latar splash (layar 1)
- about-bg.webp         1080 x 2340   latar halaman About (layar 10), sudah di-blur (gaussian r=11)
- home-banner.webp      1080 x 520    banner "Unlimited Downloads" (Home), fallback saat video belum ada
- input-header.webp     1080 x 700    header halaman Input URL
- download-footer.webp  1080 x 620    gambar Gojo untuk layar proses link & unduh (tanpa teks, atasnya sudah di-blend/fade ke hitam)
- result-thumb.webp     960 x 540     thumbnail cadangan jika media tidak punya thumbnail
- avatar.webp           512 x 512     foto profil bawaan = Gojo (user bisa ganti dari menu Profil)
- hero-poster.jpg       3840 x 2160   poster untuk assets/video/hero.mp4
- og-image.jpg          1200 x 630    preview link saat dibagikan

Bawaan app: vexora-logo.svg, vexora-icon.svg, icon-192.png, icon-512.png, icon-1024.png, icon-maskable-512.png, apple-touch-icon.png

Nama file harus persis. Kalau mau ganti gambar, timpa file dengan nama & ukuran yang sama.
Catatan: og-image paling aman pakai URL absolut (https://domainmu.com/assets/images/og-image.jpg) setelah domain Vercel fix.
