VEXORA BRAND FILES (resolusi 4K, latar transparan)

vexora-logo-4k.png          3840 x 3023   logo putih polos, crop rapat (margin 3%)
vexora-logo-chrome-4k.png   3840 x 3023   logo gradasi chrome/perak, crop rapat
vexora-logo-4k-square.png   3840 x 3840   logo putih di kanvas persegi (untuk poster/avatar/Play Store)

Sumber vektor: assets/images/vexora-logo.svg (bisa di-scale ke ukuran berapa pun tanpa pecah).
Logo di-trace dari gambar referensi menjadi poligon vektor (kecocokan 99,2%), lalu di-render ulang di 4K.
Ikon aplikasi (ada di assets/images/): icon-1024, icon-512, icon-192, icon-maskable-512, apple-touch-icon (180).

vexora-logo-with-text.png   1254 x 1254   logo + tulisan VEXORA (hasil Gemini), dipakai sebagai avatar bawaan profil.
